package com.example.hehe;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements ListFragment.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            ListFragment listFragment = new ListFragment();
            listFragment.setOnItemSelectedListener(this);

            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.fragment_list_container, listFragment);
            transaction.commit();
        }
    }

    @Override
    public void onItemSelected(String item) {
        String details;
        switch (item) {
            case "Hamlet":
                details = "Now cracks a noble heart. Good-night, sweet prince...";
                break;
            case "King Lear":
                details = "Nothing will come of nothing: speak again.";
                break;
            case "Julius Caesar":
                details = "Et tu, Brute? Then fall, Caesar.";
                break;
            default:
                details = "No details available.";
        }

        DetailFragment detailFragment = DetailFragment.newInstance(details);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_detail_container, detailFragment);
        transaction.commit();
    }
}
